package com.ensah.core.dao;

import com.ensah.core.bo.JournalisationEvenements;
import com.ensah.genericdao.GenericDao;

public interface IJournalisationEvenementsDao extends GenericDao<JournalisationEvenements , Long> {

}
