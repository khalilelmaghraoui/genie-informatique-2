package com.ensah.core.dao;

import com.ensah.core.bo.Niveau;
import com.ensah.genericdao.GenericDao;

public interface INiveauDao extends GenericDao<Niveau , Long> {

}
