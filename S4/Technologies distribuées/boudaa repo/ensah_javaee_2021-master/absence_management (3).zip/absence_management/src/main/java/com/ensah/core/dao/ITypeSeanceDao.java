package com.ensah.core.dao;

import com.ensah.core.bo.TypeSeance;
import com.ensah.genericdao.GenericDao;

public interface ITypeSeanceDao extends GenericDao<TypeSeance, Long> {


}
