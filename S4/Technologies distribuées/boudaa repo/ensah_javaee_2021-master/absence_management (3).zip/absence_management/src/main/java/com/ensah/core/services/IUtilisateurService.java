package com.ensah.core.services;

public interface IUtilisateurService {
}
