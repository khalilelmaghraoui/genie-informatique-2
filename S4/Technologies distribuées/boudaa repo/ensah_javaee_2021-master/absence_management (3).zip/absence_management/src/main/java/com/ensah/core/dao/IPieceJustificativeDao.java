package com.ensah.core.dao;

import com.ensah.core.bo.PieceJustificative;
import com.ensah.genericdao.GenericDao;

public interface IPieceJustificativeDao extends GenericDao<PieceJustificative , Long> {

}
