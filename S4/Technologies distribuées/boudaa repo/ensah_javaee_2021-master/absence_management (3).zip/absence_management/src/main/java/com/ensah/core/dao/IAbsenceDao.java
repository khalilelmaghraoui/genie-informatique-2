package com.ensah.core.dao;

import com.ensah.core.bo.Absence;
import com.ensah.genericdao.GenericDao;

public interface IAbsenceDao extends GenericDao<Absence , Long> {

}
