package com.ensah.core.dao;

import com.ensah.core.bo.CadreAdministrateur;
import com.ensah.genericdao.GenericDao;

public interface ICadreAdministrateurDao extends GenericDao<CadreAdministrateur , Long> {

}
