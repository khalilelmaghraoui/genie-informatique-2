package com.ensah.core.dao;

import com.ensah.core.bo.Conversation;
import com.ensah.genericdao.GenericDao;

public interface IConversationDao extends GenericDao<Conversation , Long> {

}
