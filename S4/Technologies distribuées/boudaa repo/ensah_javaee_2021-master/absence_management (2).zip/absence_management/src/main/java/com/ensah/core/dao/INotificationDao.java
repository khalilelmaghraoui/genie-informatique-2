package com.ensah.core.dao;

import com.ensah.core.bo.Notification;
import com.ensah.genericdao.GenericDao;

public interface INotificationDao extends GenericDao<Notification , Long> {

}
