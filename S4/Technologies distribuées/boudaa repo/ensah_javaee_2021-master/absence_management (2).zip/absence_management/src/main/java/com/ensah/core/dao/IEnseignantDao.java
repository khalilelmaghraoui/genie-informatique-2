package com.ensah.core.dao;

import com.ensah.core.bo.Enseignant;
import com.ensah.genericdao.GenericDao;

public interface IEnseignantDao extends GenericDao<Enseignant , Long> {


}
