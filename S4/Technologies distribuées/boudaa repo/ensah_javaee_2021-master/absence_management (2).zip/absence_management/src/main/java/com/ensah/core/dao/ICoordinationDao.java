package com.ensah.core.dao;

import com.ensah.core.bo.Coordination;
import com.ensah.genericdao.GenericDao;

public interface ICoordinationDao extends GenericDao<Coordination , Long> {

}
