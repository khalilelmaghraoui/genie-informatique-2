package com.ensah.core.dao;

import com.ensah.core.bo.Message;
import com.ensah.genericdao.GenericDao;

public interface IMessageDao extends GenericDao<Message , Long> {

}
