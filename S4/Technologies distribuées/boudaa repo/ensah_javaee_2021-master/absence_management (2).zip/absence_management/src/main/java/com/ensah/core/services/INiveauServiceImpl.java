package com.ensah.core.services;

import com.ensah.core.bo.Niveau;

import java.util.List;

public interface INiveauServiceImpl {


    public List<Niveau> getAllNiveau();
}
