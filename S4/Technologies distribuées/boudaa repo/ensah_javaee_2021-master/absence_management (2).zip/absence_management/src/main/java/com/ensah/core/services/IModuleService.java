package com.ensah.core.services;

import com.ensah.core.bo.Module;

import java.util.List;

public interface IModuleService {

    public List<Module> getAllModules();
}
