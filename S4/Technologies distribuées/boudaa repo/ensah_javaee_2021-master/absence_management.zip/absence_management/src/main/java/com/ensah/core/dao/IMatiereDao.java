package com.ensah.core.dao;

import com.ensah.core.bo.Matiere;
import com.ensah.genericdao.GenericDao;

public interface IMatiereDao extends GenericDao<Matiere , Long> {

}
