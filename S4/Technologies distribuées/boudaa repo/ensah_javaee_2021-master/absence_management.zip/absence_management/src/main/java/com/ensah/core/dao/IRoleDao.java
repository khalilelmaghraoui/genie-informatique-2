package com.ensah.core.dao;

import com.ensah.core.bo.Role;
import com.ensah.genericdao.GenericDao;

public interface IRoleDao extends GenericDao<Role, Long>{

}
