package com.ensah.core.dao;

import com.ensah.core.bo.Module;
import com.ensah.genericdao.GenericDao;

public interface IModuleDao extends GenericDao<Module , Long> {

}
