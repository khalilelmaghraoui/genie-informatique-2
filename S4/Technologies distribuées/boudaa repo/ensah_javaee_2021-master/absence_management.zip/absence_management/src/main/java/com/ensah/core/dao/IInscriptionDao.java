package com.ensah.core.dao;

import com.ensah.core.bo.Inscription;
import com.ensah.genericdao.GenericDao;


public interface IInscriptionDao extends GenericDao<Inscription , Long> {

}
