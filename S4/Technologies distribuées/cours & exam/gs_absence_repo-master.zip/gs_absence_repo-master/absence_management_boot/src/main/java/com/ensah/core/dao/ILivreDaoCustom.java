package com.ensah.core.dao;


public interface ILivreDaoCustom  {
}
