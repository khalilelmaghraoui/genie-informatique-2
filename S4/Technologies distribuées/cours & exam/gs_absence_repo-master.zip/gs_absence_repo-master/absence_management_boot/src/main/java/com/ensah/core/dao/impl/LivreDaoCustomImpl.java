package com.ensah.core.dao.impl;

import com.ensah.core.bo.Livre;
import com.ensah.core.dao.ILivreDaoCustom;

public class LivreDaoCustomImpl  extends GenericJpaImpl<Livre, Long> implements ILivreDaoCustom {




	
}
