package com.ensah.core.dao;

import com.ensah.core.bo.Livre;
import com.ensah.genericdao.GenericDao;

public interface ILivreDao extends GenericDao<Livre, Long> {

}
