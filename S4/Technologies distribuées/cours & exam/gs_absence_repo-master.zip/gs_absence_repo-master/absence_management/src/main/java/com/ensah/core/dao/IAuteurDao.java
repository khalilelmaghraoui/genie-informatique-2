package com.ensah.core.dao;

import com.ensah.core.bo.Auteur;
import com.ensah.genericdao.GenericDao;

public interface IAuteurDao extends GenericDao<Auteur, Long> {

}
