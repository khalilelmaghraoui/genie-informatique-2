import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;

public class ReadXMLFile {
    public static void main(final String[] args)
    {
        /*
         * Etape 1 : récupération d'une instance de la classe "DocumentBuilderFactory"
         */
        final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        try
        {
            /*
             * Etape 2 : création d'un parseur
             */
            final DocumentBuilder builder = factory.newDocumentBuilder();
            /*
             * Etape 3 : création d'un Document
             */
            final Document document= builder.parse(new File("C:\\Users\\KURAPIKA.dll\\Desktop\\TP2 XML _KHALIL EL MAGHRAOUI\\filmographie.xml"));
            //Affichage du prologue
            System.out.println("*************PROLOGUE************");
            System.out.println("version : " + document.getXmlVersion());
            System.out.println("encodage : " + document.getXmlEncoding());
            System.out.println("standalone : " + document.getXmlStandalone());
            /*
             * Etape 4 : récupération de l'Element racine
             */
            final Element racine = document.getDocumentElement();
            //Affichage de l'élément racine
            System.out.println("\n*************RACINE************");
            System.out.println(racine.getNodeName());
            /*
             * Etape 5 : récupération des movies
             */
            final NodeList racineNoeuds = racine.getChildNodes();
            final int nbRacineNoeuds = racineNoeuds.getLength();
            for (int i = 0; i<nbRacineNoeuds; i++)
            {
                if(racineNoeuds.item(i).getNodeType() == Node.ELEMENT_NODE)
                {
                    final Element movie = (Element) racineNoeuds.item(i);
                    //Affichage d'un film
                    System.out.println("\n*************MOVIE************");
                    /*

                     * Etape 6 : récupération des informations sur film
                     */
                    final Element title = (Element) movie.getElementsByTagName("title").item(0);
                    final Element genre = (Element) movie.getElementsByTagName("genre").item(0);
                    final Element releaseDate = (Element) movie.getElementsByTagName("releaseDate").item(0);
                    final Element  duration = (Element) movie.getElementsByTagName("duration").item(0);
                    final Element language = (Element) movie.getElementsByTagName("language").item(0);
                    final Element storie = (Element) movie.getElementsByTagName("storie").item(0);
                    final Element rating = (Element) movie.getElementsByTagName("rating").item(0);

                    System.out.println("Title : " + title.getTextContent());
                    System.out.println("Genre : " + genre.getTextContent());
                    System.out.println("Release Date : " + releaseDate.getTextContent());
                    System.out.println("Duration : " + duration.getTextContent());
                    System.out.println("Language : " + language.getTextContent());
                    System.out.println("Storie : " + storie.getTextContent());
                    System.out.println("Rating : " + rating.getTextContent());
                    /*
                     * Etape 7 : récupération des prizes
                     */
                    final NodeList prizes = movie.getElementsByTagName("prize");

                    final int nbPrizes = prizes.getLength();
                    System.out.println("Prizes :");
                    for(int j = 0; j<nbPrizes; j++)
                    {

                        final Element prize = (Element) prizes.item(j);

                        //Affichage du prize
                        System.out.println("         Prize"+(j+1)+" :"+ prize.getAttribute("date")+ " " +prize.getTextContent());

                    }

                    System.out.println("\n*******************STAFF*****************");
                    final Element director = (Element) movie.getElementsByTagName("director").item(0);
                    fin


                    System.out.println("Producers :");
                    final NodeList actors = movie.getElementsByTagName("producer");
                    final int nbProducers = producers.getLength();
                    for (int j = 0; j< nbProducers; j++){
                        final Element producer = (Element) producer.item(j);
                        //afficher les producteurs
                        System.out.println("         Producer: "+producer.getTextContent());
                    }
                     /*
                     * Etape 8 : récupération de l'écrivain
                     */
                    al Element writer = (Element) movie.getElementsByTagName("writer").item(0);
                    System.out.println("Writer : " +writer.getTextContent());
                    /*
                     * Etape 9 : récupération des actors
                     */
                    System.out.println("Actors :");
                    final NodeList actors = movie.getElementsByTagName("actor");
                    final int nbActors = actors.getLength();
                    for (int j = 0; j< nbActors; j++){
                        final Element actor = (Element) actors.item(j);
                        //afficher les acteurs
                        System.out.println("         Actor: "+actor.getTextContent());
                    }

                }
            }

        }
        catch (final ParserConfigurationException e)
        {
            e.printStackTrace();
        }
        catch (final SAXException e)
        {
            e.printStackTrace();
        }
        catch (final IOException e)
        {
            e.printStackTrace();
        }
    }
}
