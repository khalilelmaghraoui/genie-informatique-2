package IHM;

import javax.swing.*;

public class Exercice3 extends JFrame{

    String[] planetes = {"Venus","Mercure","la Terre","Mars","Jupiter","Saturne","Uranus","Neptune"};
    // RadioButton & Label
    JRadioButton radio1;
    JRadioButton radio2;
    ButtonGroup group;
    JLabel radio;
    //CheackBox Label & Button
    JLabel checkLabel;
    JCheckBox checkBox;

    //ComboBox Label and Button
    JLabel selectLabel;
    JComboBox box;

    //Button
    JButton btn;

    //TextArea
    JTextArea textArea;
    public Exercice3(){

        this.setLayout(null);

        radio1 = new JRadioButton("Poisson", false);
        radio2 = new JRadioButton("Mammifere", true);

        radio = new JLabel("Un Dauphin est un",JLabel.LEFT);



        radio.setBounds(15, 25, 150, 30);
        radio1.setBounds(150, 25, 100, 30);
        radio2.setBounds(280, 25, 100, 30);

        checkLabel = new JLabel("Une Araignee est un insecte",JLabel.LEFT);
        checkBox = new JCheckBox("", true);
        checkLabel.setBounds(15, 50, 200, 40);
        checkBox.setBounds(200, 60, 20, 20);

        selectLabel = new JLabel("La planete la plus proche du soleil est",JLabel.LEFT);
        box = new JComboBox(planetes);
        selectLabel.setBounds(15, 90, 300, 30);
        box.setBounds(250, 90, 80, 30);

        btn = new JButton("Corriger");
        btn.setBounds(15, 130, 100, 30);

        textArea = new JTextArea();
        textArea.setBounds(15, 180, 400, 150);
        group = new ButtonGroup();

        this.add(radio);
        this.add(radio1);
        this.add(radio2);
        this.add(checkLabel);
        this.add(checkBox);
        this.add(selectLabel);
        this.add(box);
        this.add(btn);
        this.add(textArea);

        group.add(radio1);
        group.add(radio2);
    }

    public static void main(String[] args){

        Exercice3 frame = new Exercice3();

        frame.setBounds(100, 100, 450, 450);
        frame.setTitle("QCM");
        frame.setVisible(true);

    }
}
