package IHM;

import javax.swing.*;

public class Exercice2 extends JFrame{
    //label name & field name
    JLabel labelNom;
    JTextField fieldNom;


    //lable pass and fieldpass
    JLabel labelPass;
    JPasswordField fieldPassword;
    JLabel labelNewPass;
    JPasswordField fieldNewPassword;
    JLabel labelConfirmPass;
    JPasswordField fieldConfirmPass;


    //Submit button
    JButton btn;

    public Exercice2(){
        super();

        this.setLayout(null);


        //label
        labelNom = new JLabel("Nom : ",JLabel.LEFT);
        labelPass = new JLabel("Mot de passe : ",JLabel.LEFT);
        labelNewPass = new JLabel("Nouveau mot de passe : ",JLabel.LEFT);
        labelConfirmPass = new JLabel("Retapez le mot de passe : ",JLabel.LEFT);
        btn = new JButton("Lancer la modification");


        //field
        fieldNom = new JTextField();
        labelNom.setLabelFor(fieldNom);

        fieldPassword = new JPasswordField();
        labelPass.setLabelFor(fieldPassword);

        fieldNewPassword = new JPasswordField();
        labelNewPass.setLabelFor(fieldNewPassword);

        fieldConfirmPass = new JPasswordField();
        labelConfirmPass.setLabelFor(fieldConfirmPass);
        //Bounds
        labelNom.setBounds(15, 20, 150, 30);
        fieldNom.setBounds(200, 20, 200, 30);

        labelPass.setBounds(15, 70, 150, 30);
        fieldPassword.setBounds(200, 70, 200, 30);

        labelNewPass.setBounds(15, 120, 150, 30);
        fieldNewPassword.setBounds(200, 120, 200, 30);

        labelConfirmPass.setBounds(15, 170, 150, 30);
        fieldConfirmPass.setBounds(200, 170, 200, 30);

        btn.setBounds(15, 250, 400, 30);

        this.add(labelNom);
        this.add(fieldNom);
        this.add(labelPass);
        this.add(fieldPassword);
        this.add(labelNewPass);
        this.add(fieldNewPassword);
        this.add(labelConfirmPass);
        this.add(fieldConfirmPass);
        this.add(btn);

    }

    public static void main(String[] args)
    {
        Exercice2 frame = new Exercice2();
        frame.setTitle("Change password");
        frame.setSize(450,350);
        frame.setVisible(true);
    }
}
